import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Plan } from '../models/plan';

@Injectable({
  providedIn: 'root'
})
export class PlanService {

  private BASE_URL = 'http://localhost:3333/plans';

  constructor(private http: HttpClient) {}

  // GET all plans
  getAllPlans(): Observable<Plan[]> {
    return this.http.get<Plan[]>(this.BASE_URL);
  }

  // GET plan by id
  getPlanById(id: number): Observable<Plan[]> {
    return this.http.get<Plan[]>(`${this.BASE_URL}?planId=${id}`);
  }
}
