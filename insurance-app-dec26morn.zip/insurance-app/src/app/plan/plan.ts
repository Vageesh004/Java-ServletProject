import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanService } from '../services/plan';
import { Plan } from '../models/plan';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule,HttpClientModule],
  templateUrl: './plan.html'
})
export class Plans implements OnInit {

  plans: Plan[] = [];

  constructor(private planService: PlanService) {}

  ngOnInit() {
    this.planService.getAllPlans().subscribe(data => {
       console.log('Plans data:', data);
      this.plans = data;
    });
  }
}
