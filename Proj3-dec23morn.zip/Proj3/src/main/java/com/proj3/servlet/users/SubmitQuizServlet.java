package com.proj3.servlet.users;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.proj3.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SubmitQuizServlet")
public class SubmitQuizServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            res.sendRedirect(req.getContextPath() + "/views/users/userLogin.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");
        int quizId = Integer.parseInt(req.getParameter("quizId"));
        int score = 0;

        try (Connection conn = DBConnection.getConnection()) {
            // Fetch questions for this quiz
            PreparedStatement ps = conn.prepareStatement(
                "SELECT question_id, correct_option FROM questions WHERE quiz_id=?"
            );
            ps.setInt(1, quizId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int qId = rs.getInt("question_id");
                String correct = rs.getString("correct_option");
                String userAns = req.getParameter("q_" + qId);

                if (correct.equals(userAns)) {
                    score++;
                }
            }

            // Save the attempt
            PreparedStatement insertPs = conn.prepareStatement(
                "INSERT INTO user_attempts (user_id, quiz_id, score) VALUES (?, ?, ?)"
            );
            insertPs.setInt(1, userId);
            insertPs.setInt(2, quizId);
            insertPs.setInt(3, score);
            insertPs.executeUpdate();

            req.setAttribute("score", score);
            req.setAttribute("quizId", quizId);
            req.getRequestDispatcher("/views/users/result.jsp").forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect(req.getContextPath() + "/views/users/user_dashboard.jsp");
        }
    }
}
