package com.proj3.servlet;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;

import com.proj3.util.DBConnection;

@WebServlet("/CreateQuizServlet")
public class CreateQuizServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String quizName = request.getParameter("quizName");
        String[] questionIds = request.getParameterValues("questionIds");

        HttpSession session = request.getSession(false);
        int adminId = (int) session.getAttribute("adminId");

        if (quizName == null || questionIds == null) {
            response.sendRedirect(request.getContextPath()+ "/views/createQuiz.jsp");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {

            // 1️⃣ Insert Quiz
            String quizSql = "INSERT INTO quizzes (quiz_name, created_by) VALUES (?, ?)";
            PreparedStatement psQuiz =
                    conn.prepareStatement(quizSql, Statement.RETURN_GENERATED_KEYS);

            psQuiz.setString(1, quizName);
            psQuiz.setInt(2, adminId);
            psQuiz.executeUpdate();

            ResultSet rs = psQuiz.getGeneratedKeys();
            rs.next();
            int quizId = rs.getInt(1);

            // 2️⃣ Insert Quiz Questions
            String qqSql = "INSERT INTO quiz_questions (quiz_id, question_id) VALUES (?, ?)";
            PreparedStatement psQQ = conn.prepareStatement(qqSql);

            for (String qid : questionIds) {
                psQQ.setInt(1, quizId);
                psQQ.setInt(2, Integer.parseInt(qid));
                psQQ.addBatch();
            }
            psQQ.executeBatch();

            response.sendRedirect(request.getContextPath()+ "/views/admin_dashboard.jsp");

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
