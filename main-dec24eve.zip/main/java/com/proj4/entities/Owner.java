package com.proj4.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "owner")
public class Owner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;

    private String name;
    private String phone;
    private String email;
    
    @NotNull
    @Min(value = 18, message = "Owner must be at least 18 years old")
    private int age;

   

    @JsonManagedReference
    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
    private List<PgPlace> pgPlaces;

	public Owner(String name, String phone, String email, int age, List<PgPlace> pgPlaces) {
		super();
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.age = age;
		this.pgPlaces = pgPlaces;
	}

	public Owner() {
		super();
	}
	

	public Long getOwnerId() {
		return ownerId;
	}

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

	public int getAge() {
		return age;
	}

	public List<PgPlace> getPgPlaces() {
		return pgPlaces;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setPgPlaces(List<PgPlace> pgPlaces) {
		this.pgPlaces = pgPlaces;
	}

	@Override
	public String toString() {
		return "Owner [name=" + name + ", phone=" + phone + ", email=" + email + ", age=" + age + "]";
	}

    // getters and setters
    
    
}

