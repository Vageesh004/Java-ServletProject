package com.proj4.controllers;

import com.proj4.entities.Owner;
import com.proj4.entities.PgPlace;
import com.proj4.services.OwnerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/owner")
@Tag(name = "Owner APIs", description = "Operations for Owners and their PGs")
public class OwnerController {

    private final OwnerService ownerService;

    public OwnerController(OwnerService ownerService) {
        this.ownerService = ownerService;
    }

    //owner registering
    @Operation(summary = "Register Owner", description = "Add a new owner")
    @PostMapping("/register")
    public Owner registerOwner(@Valid @RequestBody Owner owner) {
        return ownerService.registerOwner(owner);
    }

    //add pg by owner
    @Operation(summary = "Add PG by Owner", description = "Add a PG place for a specific owner")
    @PostMapping("/{ownerId}/pg")
    public PgPlace addPg(@PathVariable Long ownerId,
                         @RequestBody PgPlace pgPlace) {
        return ownerService.addPgForOwner(ownerId, pgPlace);
    }

    @Operation(summary = "View PGs of Owner", description = "List all PGs of a specific owner")
    @GetMapping("/{ownerId}/pgs")
    public List<PgPlace> getOwnerPgs(@PathVariable Long ownerId) {
        return ownerService.getPgByOwner(ownerId);
    }

    @Operation(summary = "Update availability", description = "Change availability status of a PG")
    @PutMapping("/pg/{pgId}/availability")
    public PgPlace updateAvailability(@PathVariable Long pgId,
                                      @RequestParam boolean status) {
        return ownerService.updateAvailability(pgId, status);
    }

    @Operation(summary = "Delete PG", description = "Delete a PG by its ID")
    @DeleteMapping("/pg/{pgId}")
    public ResponseEntity<String> deletePg(@PathVariable Long pgId) {
        ownerService.deletePg(pgId);
        return ResponseEntity.ok("PG deleted successfully");
    }
}
