package com.proj4.controllers;

import com.proj4.entities.Owner;
import com.proj4.entities.PgPlace;
import com.proj4.services.PgPlaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pg")
@Tag(name = "PG APIs", description = "Operations for retrieving PG information")
public class PgController {

    private final PgPlaceService pgPlaceService;

    public PgController(PgPlaceService pgPlaceService) {
        this.pgPlaceService = pgPlaceService;
    }

    



    
}
