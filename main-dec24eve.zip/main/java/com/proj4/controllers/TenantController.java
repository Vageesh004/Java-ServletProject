package com.proj4.controllers;

import com.proj4.entities.Owner;
import com.proj4.entities.PgPlace;
import com.proj4.entities.Tenant;
import com.proj4.services.PgPlaceService;
import com.proj4.services.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tenant")

@Tag(name = "Tenant APIs", description = "Operations for tenants")
public class TenantController {
	

	@Autowired
	PgPlaceService pgPlaceService;


    private final TenantService tenantService;

    public TenantController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @Operation(summary = "Register tenant", description = "Add a new tenant")
    @PostMapping("/register")
    public Tenant registerTenant(@Valid @RequestBody Tenant tenant) {
        return tenantService.saveTenant(tenant);
    }

    @Operation(summary = "Get tenant by ID", description = "Retrieve tenant details by tenant ID")
    @GetMapping("/{id}")
    public ResponseEntity<Tenant> getTenantById(@PathVariable Long id) {
        Optional<Tenant> tenant = tenantService.getTenantById(id);
        return tenant.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Delete tenant", description = "Delete a tenant by tenant ID")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTenant(@PathVariable Long id) {
        tenantService.deleteTenant(id);
        return ResponseEntity.ok("Tenant deleted successfully");
    }
    
    
    
    //pasting the codes which I have put before in pgcontroller now in tenant controller
    
    //get pgs of a city by using city name
    @Operation(summary = "Get available PGs by city", description = "Retrieve PGs available in a specific city")
    @GetMapping("/city/{city}")
    public List<PgPlace> getPgByCity(@PathVariable String city) {
    	return pgPlaceService.getAvailablePgByCity(city);
       
    }
    
    
    //get pgs of a locality by using locality name
    @Operation(summary = "Get available PGs by locality", description = "Retrieve PGs available in a specific locality")
    @GetMapping("/locality/{locality}")
    public List<PgPlace> getPgByLocality(@PathVariable String locality) {
        return pgPlaceService.getAvailablePgByLocality(locality);
    }
    
    
    //owner details retrieval by using pg id
    @Operation(summary = "Get owner of a PG", description = "Retrieve owner details of a specific PG")
    @GetMapping("/owner/{id}")
    public ResponseEntity<Owner> getOwnerDetails(@PathVariable Long id) {
        return pgPlaceService.getOwnerByPgId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    
    
    //getting pg details by id
    @Operation(summary = "Get PG details by ID", description = "Retrieve details of a specific PG place")
    @GetMapping("/details/{id}")
    public ResponseEntity<PgPlace> getPgDetails(@PathVariable Long id) {
        return pgPlaceService.getPgById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
}
