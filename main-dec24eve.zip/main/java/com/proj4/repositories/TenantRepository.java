package com.proj4.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proj4.entities.Owner;
import com.proj4.entities.PgPlace;
import com.proj4.entities.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
	
}
