package com.proj4.services;

import com.proj4.entities.Owner;
import com.proj4.entities.PgPlace;
import com.proj4.exceptions.ResourceNotFoundException;
import com.proj4.repositories.OwnerRepository;
import com.proj4.repositories.PgPlaceRepository;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PgPlaceService {

    private final PgPlaceRepository pgPlaceRepository;
    private final OwnerRepository ownerRepository;

    public PgPlaceService(PgPlaceRepository pgPlaceRepository,
                          OwnerRepository ownerRepository) {
        this.pgPlaceRepository = pgPlaceRepository;
        this.ownerRepository = ownerRepository;
    }

    public List<PgPlace> getAvailablePgByCity(String city) {
        return pgPlaceRepository.findByCityAndAvailabilityTrue(city);
    }

    public List<PgPlace> getAvailablePgByLocality(String locality) {
        return pgPlaceRepository.findByLocalityAndAvailabilityTrue(locality);
    }

    public PgPlace getPgById(Long id) {
        return pgPlaceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("PG not found with id: " + id));
    }

    public Owner getOwnerByPgId(Long pgId) {
        PgPlace pg = pgPlaceRepository.findById(pgId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("PG not found with id: " + pgId));

        return pg.getOwner();
    }

    public PgPlace addPgPlace(Long ownerId, PgPlace pgPlace) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Owner not found with id: " + ownerId));

        pgPlace.setOwner(owner);
        pgPlace.setAvailability(true);

        return pgPlaceRepository.save(pgPlace);
    }

    public List<PgPlace> getPgByOwner(Long ownerId) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Owner not found with id: " + ownerId));

        return pgPlaceRepository.findByOwner(owner);
    }

    public PgPlace updateAvailability(Long pgId, boolean availability) {
        PgPlace pg = pgPlaceRepository.findById(pgId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("PG not found with id: " + pgId));

        pg.setAvailability(availability);
        return pgPlaceRepository.save(pg);
    }

    public void deletePgPlace(Long pgId) {
        PgPlace pg = pgPlaceRepository.findById(pgId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("PG not found with id: " + pgId));

        pgPlaceRepository.delete(pg);
    }
}
