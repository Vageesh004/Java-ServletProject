package com.proj4.services;

import com.proj4.entities.Tenant;
import com.proj4.exceptions.InvalidOperationException;
import com.proj4.exceptions.ResourceNotFoundException;
import com.proj4.repositories.TenantRepository;

import org.springframework.stereotype.Service;

@Service
public class TenantService {

    private final TenantRepository tenantRepository;

    public TenantService(TenantRepository tenantRepository) {
        this.tenantRepository = tenantRepository;
    }

    // Register Tenant
    public Tenant saveTenant(Tenant tenant) {
        if (tenant.getAge() < 18) {
            throw new InvalidOperationException("Tenant must be at least 18 years old");
        }
        return tenantRepository.save(tenant);
    }

    // Get Tenant by ID
    public Tenant getTenantById(Long tenantId) {
        return tenantRepository.findById(tenantId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Tenant not found with id: " + tenantId));
    }

    // Delete Tenant
    public void deleteTenant(Long tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Tenant not found with id: " + tenantId));

        tenantRepository.delete(tenant);
    }
}
