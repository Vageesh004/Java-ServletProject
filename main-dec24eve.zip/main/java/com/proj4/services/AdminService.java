package com.proj4.services;

import com.proj4.entities.*;
import com.proj4.exceptions.ResourceNotFoundException;
import com.proj4.repositories.*;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AdminService {

    private final PgPlaceRepository pgPlaceRepository;
    private final OwnerRepository ownerRepository;
    private final TenantRepository tenantRepository;
    private final AdminRepository adminRepository;

    public AdminService(PgPlaceRepository pgPlaceRepository,
                        OwnerRepository ownerRepository,
                        TenantRepository tenantRepository,
                        AdminRepository adminRepository) {
        this.pgPlaceRepository = pgPlaceRepository;
        this.ownerRepository = ownerRepository;
        this.tenantRepository = tenantRepository;
        this.adminRepository = adminRepository;
    }

    public List<PgPlace> getAllPgPlaces() {
        return pgPlaceRepository.findAll();
    }

    public List<Owner> getAllOwners() {
        return ownerRepository.findAll();
    }

    public List<Tenant> getAllTenants() {
        return tenantRepository.findAll();
    }

    public Admin saveAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public void deletePg(Long pgId) {
        PgPlace pg = pgPlaceRepository.findById(pgId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("PG not found with id: " + pgId));

        pgPlaceRepository.delete(pg);
    }

    public void deleteOwner(Long ownerId) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Owner not found with id: " + ownerId));

        ownerRepository.delete(owner);
    }

    public void deleteTenant(Long tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Tenant not found with id: " + tenantId));

        tenantRepository.delete(tenant);
    }
}
