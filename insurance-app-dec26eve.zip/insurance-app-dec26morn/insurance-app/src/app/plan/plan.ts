import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanService } from '../services/plan';
import { Plan } from '../models/plan';
import { Router } from '@angular/router';



@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './plan.html'
})
export class Plans implements OnInit {

  plans: Plan[] = [];
  

  constructor(private planService: PlanService,private router:Router) {}

  selectPlan(plan: Plan) {
    this.router.navigate(['/payment'], {
      state: {
        ...history.state,
        planId: plan.planId,
        planName: plan.planName
      }
    });
  }

  ngOnInit() {
    this.planService.getAllPlans().subscribe(data => {
       console.log('Plans data:', data);
      this.plans = data;
    });
  }
}
