import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-questions',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './questions.html'
})
export class Questions {

  detailsForm!: FormGroup;
  premium = 0;
  showPremium = false;

  constructor(private fb: FormBuilder, private router: Router) {
    this.detailsForm = this.fb.group({
      name: ['', Validators.required],
      city: ['', Validators.required],
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      email: ['', [Validators.required, Validators.email]],
      age: ['', [Validators.required, Validators.min(1)]],
      income: ['', Validators.required],
      disease: ['', Validators.required],
     
    });
  }

  calculatePremium() {
    if (this.detailsForm.invalid) return;

    const d = this.detailsForm.value;
    let amount = 2500;

    if (d.age > 40) amount += 1000;
    if (d.income > 50000) amount += 500;
    if (d.disease === 'yes') amount += 1500;
    

    this.premium = amount;
    this.showPremium = true;
  }

  goToPlans() {
    this.router.navigate(['/plans'], {
      state: {
        user: this.detailsForm.value,
        premium: this.premium
      }
    });
  }
}
