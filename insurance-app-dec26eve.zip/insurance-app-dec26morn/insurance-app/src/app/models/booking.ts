export interface Booking {
    id?: number;
    name: string;
    city: string;
    phone: string;
    email: string;
    age: number;
    income: number;
    disease: string;
    premium: number;
  
    planId: number;
    planName: string;
  
    paymentMode: string;
    cardNumber: string;
  }
  