import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BookingService } from '../services/booking';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './payment.html'
})
export class Payment {

  paymentForm!: FormGroup;
  bookingData: any;

  success = false;

  constructor(
    private fb: FormBuilder,
    private bookingService: BookingService,
    private router: Router
  ) {
    // Data coming from plans page
    this.bookingData = history.state;

    this.paymentForm = this.fb.group({
      paymentMode: ['', Validators.required],
      cardNumber: ['', [
        Validators.required,
        Validators.pattern('^[0-9]{16}$')
      ]]
    });
  }

  submitPayment() {
    if (this.paymentForm.invalid) return;

    const booking = {
      ...this.bookingData,
      ...this.paymentForm.value
    };

    this.bookingService.createBooking(booking).subscribe(() => {
      this.success = true;
    });
  }
}

